'use strict';

import React from 'react';

require('styles//About.css');

class AboutComponent extends React.Component {
  render() {
    return (
      <div className="about-component">
        Please edit src/components///AboutComponent.js to update this component!
      </div>
    );
  }
}

AboutComponent.displayName = 'AboutComponent';

// Uncomment properties you need
// AboutComponent.propTypes = {};
// AboutComponent.defaultProps = {};

export default AboutComponent;
