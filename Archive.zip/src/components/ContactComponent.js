'use strict';

import React from 'react';

require('styles//Contact.css');

class ContactComponent extends React.Component {
  render() {
    return (
      <div className="contact-component">
        Please edit src/components///ContactComponent.js to update this component!
      </div>
    );
  }
}

ContactComponent.displayName = 'ContactComponent';

// Uncomment properties you need
// ContactComponent.propTypes = {};
// ContactComponent.defaultProps = {};

export default ContactComponent;
