'use strict';

import React from 'react';

require('styles//Faq.css');

class FaqComponent extends React.Component {
  render() {
    return (
      <div className="faq-component">
        Please edit src/components///FaqComponent.js to update this component!
      </div>
    );
  }
}

FaqComponent.displayName = 'FaqComponent';

// Uncomment properties you need
// FaqComponent.propTypes = {};
// FaqComponent.defaultProps = {};

export default FaqComponent;
